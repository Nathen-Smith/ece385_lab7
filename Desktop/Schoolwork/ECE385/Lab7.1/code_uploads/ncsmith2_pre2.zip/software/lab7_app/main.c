/*
 * main.c
 *
 *  Created on: Oct 26, 2021
 *      Author: N
 */
#include "text_mode_vga_color.h"
int main()
{
	textVGAColorScreenSaver();
	return 0;
}
