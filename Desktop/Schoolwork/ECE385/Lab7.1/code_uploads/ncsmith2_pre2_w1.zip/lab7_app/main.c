/*
 * main.c
 *
 *  Created on: Oct 26, 2021
 *      Author: N
 */
#include "text_mode_vga.h"
int main()
{
	textVGATest();
	return 0;
}
